package Kiosk.util;

public class ConsoleStyle {
    public static final String RESET = "\u001B[0m";
    public static final String BOLD  = "\u001B[1m";
    public static final String CYAN  = "\u001B[36m";

    public static String money(int amount) {
        return String.format("%,d원", amount);
    }
}
